#!/bin/bash

# Check if sudo is installed
if ! command -v sudo &> /dev/null; then
    echo "❌ 'sudo' is not installed. Please install it and try again."
    exit 1
fi

# Check if gnome-extensions is installed
if ! command -v gnome-extensions &> /dev/null; then
    echo "❌ 'gnome-extensions' is not installed. Please install it and try again."
    exit 1
fi

if [ "$EUID" -eq 0 ]; then
    echo "❌ Do not run the script with root privileges"
    exit 1
fi

USER=$(whoami)
USER_IS_SUDOER=true
CTL_PATH="/usr/local/bin/batteryhealthchargingctl-${USER}"
VISUDO_FILE="/etc/sudoers.d/batteryhealthcharging-${USER}"
SUPERUSER_CONFIGURED=false

quit_script() {
    echo "✔ Exiting the script. No changes were made."
    echo "• Please log out and log back in to restart the extension."
    exit 0
}

check_and_disable_extension() {
    if ! gnome-extensions list | grep -q "Battery-Health-Charging@maniacx.github.com"; then
        echo "Error: Battery Health Charging Extension is not installed. Please install it and try again."
        exit 1
    fi
    gnome-extensions disable Battery-Health-Charging@maniacx.github.com
}

choose_superuser_configuration() {
    echo "
Select an option to proceed:
1. Use [ sudo ] as elevated privilege to change sudo configuration (Recommended for Ubuntu based system).
2. Use [ su ] as elevated privilege to change sudo configuration. (Recommended for Debian based system)
Q. Quit the script.
Enter your option (1, 2, or Q):"
    read -r config

    case "$config" in
        1)
            SUPERUSER_CONFIGURED=true
            USER_IS_SUDOER=true
            ;;
        2)
            SUPERUSER_CONFIGURED=true
            USER_IS_SUDOER=false
            ;;
        Q|q)
            quit_script
            ;;
        *)
            echo "❌ Invalid option. Please choose a valid option (1, 2, or Q)."
            ;;
    esac
}

sudo_install_policy_rule() {
    if sudo "/home/${USER}/.local/share/gnome-shell/extensions/Battery-Health-Charging@maniacx.github.com/tool/installer.sh" "--tool-user" "${USER}" "install" &>/dev/null; then
        echo "✔ Polkit rules and ctl installed successfully."
    else
        echo "❌ Failed to install Polkit rules and ctl. Please try su mode instead."
        exit 1
    fi
}

su_install_policy_rule() {
    echo "Enter password for su to install policy rules and ctl"
    if su -c "/home/${USER}/.local/share/gnome-shell/extensions/Battery-Health-Charging@maniacx.github.com/tool/installer.sh --tool-user ${USER} install" &>/dev/null; then
        echo "✔ Polkit rules and ctl installed successfully."
    else
        echo "❌ Failed to install Polkit rules and ctl. Please check the installer and try again."
        exit 1
    fi
}

install_policy_rules() {
	check_and_disable_extension
    if [ "$SUPERUSER_CONFIGURED" = false ]; then
        choose_superuser_configuration
    fi
    if [ "$USER_IS_SUDOER" = true ]; then
        sudo_install_policy_rule
    else
        su_install_policy_rule
    fi
}

update_config_using_sudo() {
    if echo "%${USER} ALL=NOPASSWD:${CTL_PATH}" | sudo EDITOR='tee' visudo -f "${VISUDO_FILE}" &>/dev/null; then
        echo "✔ 'visudo' configuration update was successful."
    else
        echo "❌ 'visudo' configuration failed. Please try su mode instead"
        exit 1
    fi
}

update_config_using_su() {
    echo "Enter password for su to update sudo configuration"
    if su -c "echo \"%${USER} ALL=NOPASSWD:${CTL_PATH}\" | tee ${VISUDO_FILE}" &>/dev/null; then
        echo "✔ 'visudo' configuration update was successful."
    else
        echo "❌ Failed to install Polkit rules and ctl. Please check the installer and try again."
        exit 1
    fi
}

update_sudo_config() {
    if [ "$SUPERUSER_CONFIGURED" = false ]; then
        choose_superuser_configuration
    fi
    if [ "$USER_IS_SUDOER" = true ]; then
        update_config_using_sudo
    else
        update_config_using_su
    fi
}

helper_file="/home/${USER}/.local/share/gnome-shell/extensions/Battery-Health-Charging@maniacx.github.com/lib/helper.js"
driver_file="/home/${USER}/.local/share/gnome-shell/extensions/Battery-Health-Charging@maniacx.github.com/lib/driver.js"

replace_pkexec_with_sudo() {
    local file=$1
    if [[ -f $file ]]; then
        sed -i 's/\bpkexec\b/sudo/g' "$file" && return 0 || return 1
    else
        echo "❌ Error: File $file does not exist."
        return 1
    fi
}

patch_extension() {
	check_and_disable_extension
    if replace_pkexec_with_sudo "$helper_file" && replace_pkexec_with_sudo "$driver_file"; then
        echo "✔ Battery Health Charging extension patched successfully."
    else
        echo "❌ Failed to patch the Battery Health Charging extension. Please check the files."
        exit 1
    fi
}

remove_config_using_sudo() {
    if sudo rm -f "${VISUDO_FILE}"; then
        echo "✔ Removed sudo configuration."
    else
        echo "❌ Failed to remove sudo configuration. Please try su mode instead."
        exit 1
    fi
}

remove_config_using_su() {
    echo "Enter password for su to remove sudo configuration"
    if su -c "rm -f ${VISUDO_FILE}"; then
        echo "✔ Removed sudo configuration."
    else
        echo "❌ Failed to remove sudo configuration."
        exit 1
    fi
}

remove_sudo_config() {
    if [ "$SUPERUSER_CONFIGURED" = false ]; then
        choose_superuser_configuration
    fi
    if [ "$USER_IS_SUDOER" = true ]; then
        remove_config_using_sudo
    else
        remove_config_using_su
    fi
}

echo "
This script is a workaround for a recent Polkit bug introduced in Ubuntu/Debian systems.
This bug causes delayed execution, making the Battery Health Charging extension unusable."

echo "
Select an option to proceed:

Installation:
1. Install Polkit rules and the batteryhealthchargingctl (required if not already installed).
2. Modify the sudo configuration to allow the user/extension to run batteryhealthchargingctl without requiring a password.
3. Patch the Battery Health Charging extension by replacing pkexec with sudo.
A. Perform all of the above operations.

Uninstallation:
4. Remove the sudo configuration that allows the user/extension to run batteryhealthchargingctl without a password.

Q. Quit the script.

Enter your option (1-4, A, or Q):"
read -r response

case "$response" in
    1)
        install_policy_rules
        ;;
    2)
        update_sudo_config
        ;;
    3)
        patch_extension
        ;;
    A|a)
        install_policy_rules
        update_sudo_config
        patch_extension
        ;;
    4)
        remove_sudo_config
        ;;
    Q|q)
        quit_script
        ;;
    *)
        echo "❌ Invalid option. Please choose a valid option (1-4, A, or Q)."
        ;;
esac

